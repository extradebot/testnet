<?php

namespace Modules\ManualDeposit\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Nwidart\Modules\Facades\Module;

class ManualDepositMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
       
        $check = checkAddon('manualdeposit');
        $status = $check['status'] ?? 'fail' ;
        if ($status  == 'fail') {
            $module = Module::find('manualdeposit');
            $module->disable();
        }
        return $next($request);
    }
    
}
