@if (websiteInfo('trader_mode') == 'enabled' && isAddonEnabled('cryptotrading'))
    @include('themes.prius.user.trade.trade.index')    
@else
    @include('themes.prius.user.dashboard-content')
@endif